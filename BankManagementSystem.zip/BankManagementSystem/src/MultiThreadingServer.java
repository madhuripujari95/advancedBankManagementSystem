
import java.io.*;
import java.net.*;
import java.util.Date;
import javax.swing.*;

import java.sql.*;


public class MultiThreadingServer extends JFrame implements Runnable {
  
	private JTextArea ta;
	private static final long serialVersionUID = 1L; 
	private int clientNo = 0;
	PreparedStatement updateStatement;
  
  public MultiThreadingServer() {
	  ta = new JTextArea(10,10);
	  JScrollPane sp = new JScrollPane(ta);
	  this.add(sp);
	  this.setTitle("MultiThreadServer");
	  this.setSize(400,200);
	  Thread t = new Thread(this);
	  t.start();
  }

  public void run() {
	  try {
        // Create a server socket 
        ServerSocket serverSocket = new ServerSocket(8000);
        
        ta.append("MultiThreadServer started at " + new Date() + '\n');
    
        while (true) {
          // Listen for a new connection request
          Socket socket = serverSocket.accept();
         
          clientNo++;
    
          // Create and start a new thread for the connection
          new Thread(new HandleAClient(socket, clientNo)).start();
        }
      }
      catch(IOException ex) {
        System.err.println(ex);
      }
	    
  }
  
  // Define the thread class for handling new connection
  class HandleAClient implements Runnable {
    private Socket socket; // A connected socket
    private int clientNum;
    
    /** Construct a thread */
    public HandleAClient(Socket socket, int clientNum) {
      this.socket = socket;
      this.clientNum = clientNum;
    }

    /** Run a thread */
    public void run() {
      try {
        // Create data input and output streams
        DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());

        while (true) {    

        	int Flag = inputFromClient.readInt();
    	  	int AccountNumber = inputFromClient.readInt();
          	int Amount = inputFromClient.readInt();
          	int CurrentAmount	= inputFromClient.readInt();
          		        
        	if(Flag == 1) {
        		String updateSQLDeposit = "	UPDATE bank SET amount = ? WHERE AccNumber = ?" ;
     		    
     	        Connection connection =null;
     			try {
     				connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
     			} catch (SQLException e) {
     				e.printStackTrace();
       				System.out.println("Deposit - Error in open DB connection - Multithreading");
     				System.exit(0);
     			}
     		    System.out.println("Database connected from Server");
     			
     		    try{
     			  	updateStatement = connection.prepareStatement(updateSQLDeposit);
     				updateStatement.setInt(1, CurrentAmount + Amount);
     				updateStatement.setInt(2, AccountNumber);
     				updateStatement.execute(); 
     				System.out.println("Executed Deposit Money Update Statement!");
     				
     				ta.append("Deposit of " + Amount + " dollars made into Account number " + AccountNumber +  '\n');
     	    	  
     		    } catch (SQLException e) {
     				e.printStackTrace();
       				System.out.println("Deposit - Error in prepareStatement- Multithreading");
     			} finally {
         		   try {
           			connection.close();
           		   } catch (SQLException e) {
           				e.printStackTrace();
           				System.out.println("Deposit - Error in close DB connection - Multithreading");
           				System.exit(0);
           			}
           		 }
     			
        	}
        	else {
        		String updateSQLWithdrawal = "UPDATE bank SET amount = ? WHERE AccNumber = ?" ;
        		
        		// Connect to a database
        		Connection connection =null;
        		try {
        			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
        		} catch (SQLException e) {
        			e.printStackTrace();
        			System.out.println("Withdraw - Error in open connection - Multithreading");
        			System.exit(0);
        		}
        		System.out.println("Database connected");
        				
        		try{ 	
        		  	updateStatement = connection.prepareStatement(updateSQLWithdrawal);
        			updateStatement.setInt(1, CurrentAmount - Amount);
        			updateStatement.setInt(2, AccountNumber);
        			updateStatement.execute();

        		} catch (SQLException e) {
        			e.printStackTrace();
        			System.out.println("Withdraw - Error in prepareStatement- Multithreading");

        		} finally {
        		   try {
        			connection.close();
        		   } catch (SQLException e) {
        				e.printStackTrace();
        				System.out.println("Withdraw - Error in close DB connection - Multithreading ");
        				System.exit(0);
        			}
        		 }

               
     			ta.append("Withdrawal of " + Amount + " dollars from Account number " + AccountNumber + '\n');
        	}
        	
	        
        }
      	} catch(IOException ex) {
      		System.out.println(" ");
        } 
      
    }
  }
   
  
  public static void main(String[] args) {
    MultiThreadingServer mts = new MultiThreadingServer();
    mts.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mts.setVisible(true);
  }
}