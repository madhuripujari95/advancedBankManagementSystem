import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.text.*;

public class BankSystem extends JFrame implements ActionListener {

	//Main area on GUI where all Windows will be displayed
	private JDesktopPane desktop = new JDesktopPane ();
	
	private static final long serialVersionUID = 1L; 
	
	//MenuBar.
	private JMenuBar bar;

	//Main Menu
	private JMenu mnuFile, mnuEdit, mnuView;
	private JMenu mnuWin;

	private JMenuItem addNew, end;						// Navigation Options in Account
	private	JMenuItem  deposit, withdraw;	 			//Navigation Options in Transfer Funds
	private	JMenuItem  allCustomer, search;;			//View Navigation bar
	private JMenuItem close, closeAll;					// Options in Window

	//PopupMenu of GUI
	private JPopupMenu popMenu = new JPopupMenu ();
	private JMenuItem open, dep, with, find, all; //Menu Items of Pop-up GUI

	//ToolBar.
	private	JToolBar toolBar;

	//ToolBar Buttons
	private	JButton btnNew, btnDep, btnWith, btnSrch;
	
	//StatusBar where Program's Name & Welcome Message Display
	private JPanel statusBar = new JPanel ();

	//Labels for Displaying Program's Name & saying Welcome to Current User on StatusBar.
	private JLabel welcome;
	private JLabel author;


	//Getting the Current System Date.
	private java.util.Date currDate = new java.util.Date ();
	private SimpleDateFormat sdf = new SimpleDateFormat ("dd MMMM yyyy", Locale.getDefault());
	private String d = sdf.format (currDate);



	public BankSystem () {
		super ("Gringotts Wizarding Bank Management System");
		
		
		//Creating the MenuBar.
		bar = new JMenuBar ();

		//Setting the Main Window of Program.
		setIconImage (getToolkit().getImage ("src/Images/Bank.png"));
		setSize (700, 550);
		setJMenuBar (bar);

		//Closing Code of Main Window.
		addWindowListener (new WindowAdapter () {
			public void windowClosing (WindowEvent we) {
				closeApp ();
			}
		}
		);

		//Setting the Location of Application on Screen.
		setLocation((Toolkit.getDefaultToolkit().getScreenSize().width  - getWidth()) / 2,
			(Toolkit.getDefaultToolkit().getScreenSize().height - getHeight()) / 2);

		//Creating the MenuBar Items.
		mnuFile = new JMenu ("Account");
		mnuFile.setMnemonic ((int)'F');
		
		mnuEdit = new JMenu ("Transfer Funds");
		mnuEdit.setMnemonic ((int)'E');
		
		mnuView = new JMenu ("View");
		mnuView.setMnemonic ((int)'V');
		
		mnuWin = new JMenu ("Window");
		mnuWin.setMnemonic ((int)'W');


		//Creating the MenuItems of Program.
		//MenuItems for Account 
		addNew = new JMenuItem ("Open New Account", new ImageIcon ("src/Images/open.png"));
		addNew.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_N, Event.CTRL_MASK));
		addNew.setMnemonic ((int)'N');
		addNew.addActionListener (this);

		end = new JMenuItem ("Quit ", new ImageIcon ("src/Images/exit.png"));
		end.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_Q, Event.CTRL_MASK));
		end.setMnemonic ((int)'Q');	
		end.addActionListener (this);

		//MenuItems for Transfer Funds.
		deposit = new JMenuItem ("Deposit Money", new ImageIcon ("src/Images/deposit.png"));
		deposit.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_T, Event.CTRL_MASK));
		deposit.setMnemonic ((int)'T');
		deposit.addActionListener (this);
		withdraw = new JMenuItem ("Withdraw Money", new ImageIcon ("src/Images/withdraw.png"));
		withdraw.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_W, Event.CTRL_MASK));
		withdraw.setMnemonic ((int)'W');	
		withdraw.addActionListener (this);




		//MenuItems for View.

		allCustomer = new JMenuItem ("View all Customer Details ", new ImageIcon ("src/Images/page.png"));
		allCustomer.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_A, Event.CTRL_MASK));
		allCustomer.setMnemonic ((int)'A');
		allCustomer.addActionListener (this);
		
		search = new JMenuItem ("Search By Account Number", new ImageIcon ("src/Images/search.png"));
		search.setAccelerator (KeyStroke.getKeyStroke(KeyEvent.VK_S, Event.CTRL_MASK));
		search.setMnemonic ((int)'S');	
		search.addActionListener (this);


		//MenuItems for WindowMenu.
		close = new JMenuItem ("Close Active Window", new ImageIcon ("src/Images/closeActive.png"));
		close.setMnemonic ((int)'C');
		close.addActionListener (this);
		closeAll = new JMenuItem ("Close All Windows...", new ImageIcon ("src/Images/closeAll.png"));
		closeAll.setMnemonic ((int)'A');
		closeAll.addActionListener (this);


		//Adding MenuItems to Menu.
	
		//Account Menu Items.
		mnuFile.add (addNew);
		mnuFile.addSeparator ();
		mnuFile.add (end);

		//Transfer Funds Menu Items.
		mnuEdit.add (deposit);
		mnuEdit.addSeparator ();
		mnuEdit.add (withdraw);


		//View Menu Items.
		mnuView.add (allCustomer);
		mnuView.addSeparator ();
		mnuView.add (search);

		//Window Menu Items.
		mnuWin.add (close);
		mnuWin.add (closeAll);


		//Adding Menu Items to the bar
		bar.add (mnuFile);
		bar.add (mnuEdit);
		bar.add (mnuView);
		bar.add (mnuWin);

		//MenuItems for PopupMenu.
		open = new JMenuItem ("Open New Account", new ImageIcon ("src/Images/open.png"));
		open.addActionListener (this);
		
		dep = new JMenuItem ("Deposit Money");
		dep.addActionListener (this);
		with = new JMenuItem ("Withdraw Money");
		with.addActionListener (this);
		

		find = new JMenuItem ("Search Customer", new ImageIcon ("src/Images/search.png"));
		find.addActionListener (this);
		all = new JMenuItem ("View All Customer", new ImageIcon ("src/Images/page.png"));
		all.addActionListener (this);

		//Adding Menues to PopupMenu.
		popMenu.add (open);
		popMenu.add (dep);
		popMenu.add (with);
		popMenu.add (find);
		popMenu.add (all);

		//Following Procedure display the PopupMenu of Program.
		addMouseListener (new MouseAdapter () {
			public void mousePressed (MouseEvent me) { checkMouseTrigger (me); }
			public void mouseReleased (MouseEvent me) { checkMouseTrigger (me); }
			private void checkMouseTrigger (MouseEvent me) {
				if (me.isPopupTrigger ())
					popMenu.show (me.getComponent (), me.getX (), me.getY ());
			}
		}
		);
		
		//Creating the ToolBar's Buttons of Program.
		btnNew = new JButton (new ImageIcon ("src/Images/newuser.png"));
		btnNew.setToolTipText ("Create New Account");
		btnNew.addActionListener (this);
		btnDep = new JButton (new ImageIcon ("src/Images/depositmoney.png"));
		btnDep.setToolTipText ("Deposit Money");
		btnDep.addActionListener (this);
		btnWith = new JButton (new ImageIcon ("src/Images/withdrawmoney.png"));
		btnWith.setToolTipText ("Withdraw Money");
		btnWith.addActionListener (this);

		
		btnSrch = new JButton (new ImageIcon ("src/Images/searchcust.png"));
		btnSrch.setToolTipText ("Search Customer");
		btnSrch.addActionListener (this);
	

		//Creating the ToolBar of Program.
		toolBar = new JToolBar ();
		toolBar.add (btnNew);
		toolBar.addSeparator ();
		toolBar.add (btnDep);
		toolBar.addSeparator ();
		toolBar.add (btnWith);
		toolBar.addSeparator ();
		toolBar.add (btnSrch);

		//StatusBar
		author = new JLabel (" " + "Gringotts Bank", Label.LEFT);
		author.setForeground (Color.black);
		author.setToolTipText ("Bank System Title");
		welcome = new JLabel ( d + " ", JLabel.RIGHT);
		welcome.setForeground (Color.black);
		welcome.setToolTipText ("Current Date");
		statusBar.setLayout (new BorderLayout());
		statusBar.add (author, BorderLayout.WEST);
		statusBar.add (welcome, BorderLayout.EAST);

		//For Making the Dragging Speed of Internal Frames Faster
		desktop.putClientProperty ("JDesktopPane.dragMode", "outline");

		//Setting the Contents of Programs
		getContentPane().add (toolBar, BorderLayout.NORTH);
		getContentPane().add (desktop, BorderLayout.CENTER);
		getContentPane().add (statusBar, BorderLayout.SOUTH);

		//Showing The Main Form of Application
		setVisible (true);

	}

	//Function For Performing different Actions By Menus of Program.

	public void actionPerformed (ActionEvent ae) {
	
		Object obj = ae.getSource();

		if (obj == addNew || obj == open || obj == btnNew) {

			boolean b = openChildWindow ("Open New Account");
			if (b == false) {
				NewAccount newAccount = new NewAccount ();
				desktop.add (newAccount);
				newAccount.show ();
			}

		}
		else if (obj == end) {

			closeApp ();

		}
		else if (obj == deposit || obj == dep || obj == btnDep) {

			boolean b = openChildWindow ("Deposit Money");
			if (b == false) {
				DepositMoney depositMoney = new DepositMoney ();
				desktop.add (depositMoney);
				depositMoney.show ();
			}

		}
		else if (obj == withdraw || obj == with || obj == btnWith) {

			boolean b = openChildWindow ("Withdraw Money");
			if (b == false) {
				WithdrawMoney withdrawMoney = new WithdrawMoney ();
				desktop.add (withdrawMoney);
				withdrawMoney.show ();
			}

		}

		else if (obj == search || obj == find || obj == btnSrch) {

			boolean b = openChildWindow ("Search Customer by account number");
			if (b == false) {
				FindAccount findAccount = new FindAccount ();
				desktop.add (findAccount);
				findAccount.show ();
			}

		}

		else if (obj == allCustomer || obj == all) {

			boolean b = openChildWindow ("View All Account Holders");
			if (b == false) {
				ViewCustomer viewCustomerInfo = new ViewCustomer ();
				desktop.add (viewCustomerInfo);
				viewCustomerInfo.show ();
			}

		}

		else if (obj == close) {

			try {
				desktop.getSelectedFrame().setClosed(true);
			}
			catch (Exception CloseExc) { }

		}
		else if (obj == closeAll) {

			JInternalFrame Frames[] = desktop.getAllFrames (); //Getting all Open Frames.
			for(int getFrameLoop = 0; getFrameLoop < Frames.length; getFrameLoop++) {
				try {
	 				Frames[getFrameLoop].setClosed (true); //Close the frame.
				} 
				catch (Exception CloseExc) { }	//if we can't close it then we have a problem.
			}

		}

	}


	//Function For Closing the Program.

	private void closeApp () {

		try {
			//Show a Confirmation Dialog.
		    	int reply = JOptionPane.showConfirmDialog (this,
					"Are you sure you want to exit\nFrom BankSystem?",
					"BankSystem - Exit", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
			//Check the User Selection.
			if (reply == JOptionPane.YES_OPTION) {
				setVisible (false);	//Hide the Frame.
				dispose();            	//Free the System Resources.
				
				System.exit (0);        //Close the Application.
			}
			else if (reply == JOptionPane.NO_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		} 

		catch (Exception e) {}

	}


	//Loop Through All the Opened JInternalFrame to Perform the Task.

	private boolean openChildWindow (String title) {

		JInternalFrame[] instance = desktop.getAllFrames ();
		for (int i = 0; i < instance.length; i++) {
			if (instance[i].getTitle().equalsIgnoreCase (title)) {
				instance[i].show ();
				return true;
			}
		}
		return false;

	}


}