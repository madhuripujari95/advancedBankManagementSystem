import java.awt.*;
import java.io.IOException;
import java.net.Socket;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class BankSystemMain extends JWindow {

	private Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
	private static final long serialVersionUID = 1L; 
	Socket socket = null;

	public BankSystemMain () {

		JLabel lbImage    = new JLabel ();
		Color cl = new Color (0, 0, 0);
		lbImage.setBorder (new LineBorder (cl, 1));

		getContentPane().add (lbImage, BorderLayout.CENTER);
		
		pack();

		setSize (getSize().width, getSize().height);
		setLocation (d.width / 2 - getWidth() / 2, d.height / 2 - getHeight() / 2);

		
		for (int i = 0; i <= 2000; i++) { }
		
		try {
			socket = new Socket("localhost", 8000);
			System.out.println("Client Request initiated from Main Class");
		} catch (IOException e1) {
			e1.printStackTrace();
			System.out.println("Client request failed");
		}

		new BankSystem ();

		toFront();
		dispose ();
		setVisible (false);

	}

	public static void main (String args[]) {
		
		new BankSystemMain ();

	}

}
