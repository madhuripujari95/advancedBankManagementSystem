import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;

public class ViewCustomer extends JInternalFrame {

	private JPanel jpShow = new JPanel ();

	private DefaultTableModel dtmCustomer;
	private JTable tbCustomer;
	private JScrollPane jspTable;

	private int total = 0;

	//String Type Array use to Load Records into File.
	private String rowData[][];


	ViewCustomer () {
		super ("View All Account Holders", false, true, false, true);
		setSize (475, 280);

		jpShow.setLayout (null);

		populateArray ();

		tbCustomer = makeTable ();
		jspTable = new JScrollPane (tbCustomer);
		jspTable.setBounds (20, 20, 425, 200);

		//Adding the Table to Panel.
		jpShow.add (jspTable);

		//Adding Panel to Window.
		getContentPane().add (jpShow);

		//In the End Showing the New Account Window.
		setVisible (true);

	}

	//Function use to load all Records from File when Window Open.
	void populateArray () {
		
		Connection connection =null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("ViewCustomer - Error in open connection");
			System.exit(0);
		}
		System.out.println("Database connected");
				
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ViewCustomer - Error in createStatement connection");
					System.exit(0);
				}
				
	   ResultSet resultSet = null;
	   ResultSet resultSetCount = null;
	   
	   try {
		   
		   resultSetCount = statement.executeQuery("SELECT COUNT(*) FROM bank");
		   total = resultSetCount.getInt(1);
		   System.out.println("Total row count :" + total);
		   
		   
		   resultSet = statement.executeQuery("SELECT rowid, * FROM bank");
		  
		   
		   rowData = new String [total][4];
		   
		   if (total == 0) {
				JOptionPane.showMessageDialog (null, "No Customers added.\n Please go to add account option to add new customer!",
							"Invalid Input - ", JOptionPane.PLAIN_MESSAGE);
			} 
		   else {
					while (resultSet.next()) {
						int rowid = Integer.parseInt(resultSet.getString(1))-1;
						
						rowData[rowid][0] = resultSet.getString(2);
						rowData[rowid][1] = resultSet.getString(3);
						rowData[rowid][2] = resultSet.getString(4) + ", " + resultSet.getString(5)  + ", " + resultSet.getString(6) ;
						rowData[rowid][3] = resultSet.getString(7) ;
					}	
				}
		   }catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ViewCustomer - Error in select query region connection");
					System.exit(0);
				}

	   // Close the connection
	   finally {
		   try {
			   connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ViewCustomer - Error in close connection");
					System.exit(0);
				}
			   }

	}

	//Function to Create the Table and Add Data to Show.
	private JTable makeTable () {

		//String Type Array use to Give Table Column Names.
		String cols[] = {"Account Number", "Customer Name", "Opening Date", "Bank Balance"};

		dtmCustomer  = new DefaultTableModel (rowData, cols);
		tbCustomer = new JTable (dtmCustomer) {
			public boolean isCellEditable (int iRow, int iCol) {
				return false;	//Disable All Columns of Table.
			}
		};
		//Sizing the Columns of Table.
		(tbCustomer.getColumnModel().getColumn(0)).setPreferredWidth (180);
		(tbCustomer.getColumnModel().getColumn(1)).setPreferredWidth (275);
		(tbCustomer.getColumnModel().getColumn(2)).setPreferredWidth (275);
		(tbCustomer.getColumnModel().getColumn(3)).setPreferredWidth (200);
		tbCustomer.setRowHeight (20);
		tbCustomer.setSelectionMode (ListSelectionModel.SINGLE_SELECTION);
		return tbCustomer;

	}

}