import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class FindAccount extends JInternalFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;

	private JPanel jpFind = new JPanel();
	private JLabel lbNo, lbName, lbDate, lbBal;
	private JTextField txtAccountNumber, txtCustomerName, txtDate, txtBal;
	private JButton btnFind, btnCancel;

		//Create text fields for user to put input
	FindAccount () {

		
		super ("Search Customer by account number", false, true, false, true);
		setSize (400, 240);

		jpFind.setLayout (null);
		//Aligning all titles and text fields
		lbNo = new JLabel ("Account Number");
		lbNo.setForeground (Color.black);
		lbNo.setBounds(15, 20, 120, 35);
	    lbName = new JLabel ("Customer Name:");
		lbName.setForeground (Color.black);
	    lbName.setBounds(15, 55, 120, 35);
		lbDate = new JLabel ("Last Transaction:");
		lbDate.setForeground (Color.black);
		lbDate.setBounds(15, 90, 120, 35);
		lbBal = new JLabel ("Available Balance:");
		lbBal.setForeground (Color.black);
		lbBal.setBounds(15, 125, 120, 35);
		

		txtAccountNumber = new JTextField ();
		txtAccountNumber.setHorizontalAlignment (JTextField.RIGHT);
		txtAccountNumber.setBounds (135, 25, 230, 25);
		txtCustomerName = new JTextField ();
		txtCustomerName.setEnabled (false);
		txtCustomerName.setHorizontalAlignment (JTextField.RIGHT);
		txtCustomerName.setBounds (135, 60, 230, 25);
		txtDate = new JTextField ();
		txtDate.setEnabled (false);
		txtDate.setBounds (135, 90, 230, 25);
		txtBal = new JTextField ();
		txtBal.setHorizontalAlignment (JTextField.RIGHT);
		txtBal.setEnabled (false);
		txtBal.setBounds(135, 130, 230, 25);
		
		
		//Restricting user input to numeric
		txtAccountNumber.addKeyListener (new KeyAdapter() {
		public void keyTyped (KeyEvent ke) {
				char c = ke.getKeyChar ();
				if (!((Character.isDigit (c) || (c == KeyEvent.VK_BACK_SPACE)))) {
					getToolkit().beep ();
					ke.consume ();
      				}
    			}
  			}
		);

		//To align Search and Cancel button
		btnFind = new JButton ("Search");
		btnFind.setBounds(35, 165, 120, 25);
		btnFind.addActionListener (this);
		btnCancel = new JButton ("Cancel");
		btnCancel.setBounds(200, 165, 120, 25);
		btnCancel.addActionListener (this);
		

		//Adding the All the Controls to Panel.
		jpFind.add (lbNo);
		jpFind.add (txtAccountNumber);
		jpFind.add (lbName);
		jpFind.add (txtCustomerName);
		jpFind.add (lbDate);
		jpFind.add (txtDate);
		jpFind.add (lbBal);
		jpFind.add (txtBal);
		jpFind.add (btnFind);
		jpFind.add (btnCancel);

		//Adding Panel to Window.
		getContentPane().add (jpFind);


		//In the End Showing the New Account Window.
		setVisible (true);

	}

	//Function use By Buttons of Window to Perform Action as User Click Them.
	public void actionPerformed (ActionEvent ae) {

		
		Object obj = ae.getSource();

		if (obj == btnFind) {
			if (txtAccountNumber.getText().equals("")) {
				JOptionPane.showMessageDialog (this, "Invalid Input for account number, can't be empty",
						"Invalid Input", JOptionPane.PLAIN_MESSAGE);
				txtAccountNumber.requestFocus();
			}
			
			else {
				findBankAccount ();	
			}
			}
		if (obj == btnCancel) {
			setVisible (false);
			dispose();
		}

	}
	//Searching for account based on Account number provided
	void findBankAccount () {

		boolean found = false;
		Connection connection =null;
		try {
			connection = DriverManager.getConnection
			  ("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception in open connection - findBankAccount ");
			System.exit(0);;
		}
		System.out.println("Database connected");
				
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Exception in create statement connection - findBankAccount ");
					System.exit(0);
				}
				
			    // Execute a statement
			    ResultSet resultSet = null;
				try {
					resultSet = statement.executeQuery("SELECT COUNT(1) FROM bank WHERE AccNumber = " + txtAccountNumber.getText());
					
					int count = resultSet.getInt(1);
				
				
					if(count>0) {
						found = true;
						JOptionPane.showMessageDialog (this, "Account No. " + txtAccountNumber.getText () + " found!.",
								"Valid", JOptionPane.PLAIN_MESSAGE);
				
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Exception in open DB connection - findBankAccount ");
							System.exit(0);
						} 
						
						displayBankAccount();
						
					}
					else{
						JOptionPane.showMessageDialog (this, "Account No. " + txtAccountNumber.getText () + " does not exist!",
								"Incorrect Account Number", JOptionPane.PLAIN_MESSAGE);
						
						System.out.println("No record in resultset:  " +count);
						
						
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Exception in open DB connection - findBankAccount ");
							System.exit(0);
						} 
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Exception in close DB connection - findBankAccount ");
					System.exit(0);
				}
	
	}

	//Function which display Record from Array onto the Form.
	public void displayBankAccount () {
		
		
		Connection connection =null;
		
		try {
			connection = DriverManager.getConnection
			  ("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			
			e.printStackTrace();
			System.out.println("Exception in open DB connection - displayBankAccount ");
			System.exit(0);;
		}
		System.out.println("Database connected");
		

		
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Exception in open DB connection - displayBankAccount ");
					System.exit(0);
				}

		 ResultSet resultSet = null;
			try {
				resultSet = statement.executeQuery("SELECT * FROM bank WHERE AccNumber = " + Integer.parseInt(txtAccountNumber.getText()));
				
				txtAccountNumber.setText (resultSet.getString(1));
				txtCustomerName.setText (resultSet.getString(2));
				txtDate.setText(resultSet.getString(3)+","+resultSet.getString(4)+","+resultSet.getString(5));
				
				txtBal.setText(resultSet.getString(6));		
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Exception in open DB connection - displayBankAccount ");
				System.exit(0);
			}
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Exception in open DB connection - displayBankAccount ");
				System.exit(0);
			} 
		
	}


}	