import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class NewAccount extends JInternalFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L;

	private JPanel jpInfo = new JPanel();
	private JLabel lbNo, lbName, lbDate, lbDeposit;
	private JTextField txtAccountNumber, txtCustomerName, txtDeposit;
	private JComboBox Month, Day, Year;
	private JButton btnSave, btnCancel;


	PreparedStatement insertStatement, updateStatement, deleteStatement;

 
	//to create new account
	NewAccount () {

		super ("Open New Account", false, true, false, true);
		setSize (400, 240);

		jpInfo.setBounds (0, 0, 500, 115);
		jpInfo.setLayout (null);
		//Aligning all titles and text fields
		lbNo = new JLabel ("Account Number:");
		lbNo.setForeground (Color.black);
		lbNo.setBounds(15, 20, 120, 35);
	    lbName = new JLabel ("Customer Name:");
		lbName.setForeground (Color.black);
	    lbName.setBounds (15, 55, 120, 35);
		lbDate = new JLabel ("Deposit Date:");
		lbDate.setForeground (Color.black);
		lbDate.setBounds (15, 90, 120, 35);
		lbDeposit = new JLabel ("Deposit Amount:");
		lbDeposit.setForeground (Color.black);
		lbDeposit.setBounds (15, 125, 120, 35);

		txtAccountNumber = new JTextField ();
		txtAccountNumber.setHorizontalAlignment (JTextField.RIGHT);
		txtAccountNumber.setBounds (135, 25, 230, 25);
		txtCustomerName = new JTextField ();
		txtCustomerName.setHorizontalAlignment (JTextField.RIGHT);
		txtCustomerName.setBounds (135, 60, 230, 25);
		txtDeposit = new JTextField ();
		txtDeposit.setHorizontalAlignment (JTextField.RIGHT);
		txtDeposit.setBounds (135, 130, 230, 25);


		
		//Restricting The User Input to only Numerics in Numeric TextBoxes.
		txtAccountNumber.addKeyListener (new KeyAdapter() {
			public void keyTyped (KeyEvent ke) {
				char c = ke.getKeyChar ();
				if (!((Character.isDigit (c) || (c == KeyEvent.VK_BACK_SPACE)))) {
					getToolkit().beep ();
					ke.consume ();
      				}
    			}
  		}
		);
		txtDeposit.addKeyListener (new KeyAdapter() {
			public void keyTyped (KeyEvent ke) {
				char c = ke.getKeyChar ();
				if (!((Character.isDigit (c) || (c == KeyEvent.VK_BACK_SPACE)))) {
					getToolkit().beep ();
					ke.consume ();
      				}
    			}
  		}
		);

		//Creating Date Option.
		String Months[] = {"January", "February", "March", "April", "May", "June",
			"July", "August", "September", "October", "November", "December"};
		 Month = new JComboBox (Months);
		 Day = new JComboBox ();
		 Year = new JComboBox ();
		for (int i = 1; i <= 31; i++) {
			String days = "" + i;
			 Day.addItem (days);
		}
		for (int i = 2000; i <= 2022; i++) {
			String years = "" + i;
			 Year.addItem (years);
		}
		
		
		//Aligning The Date Option Controls.
		Month.setBounds (135, 98, 100, 25);
		Day.setBounds (230, 98, 60, 25);
		Year.setBounds (285, 98, 85, 25);

		//Aligning The Buttons.
		btnSave = new JButton ("Save");
		btnSave.setBounds (40, 165, 120, 25);
		btnSave.addActionListener (this);
		btnCancel = new JButton ("Cancel");
		btnCancel.setBounds (205, 165, 120, 25);
		btnCancel.addActionListener (this);

		//Adding the All the Controls to Panel.
		jpInfo.add (lbNo);
		jpInfo.add (txtAccountNumber);
		jpInfo.add (lbName);
		jpInfo.add (txtCustomerName);
		jpInfo.add (lbDate);
		jpInfo.add (Month);
		jpInfo.add (Day);
		jpInfo.add (Year);
		jpInfo.add (lbDeposit);
		jpInfo.add (txtDeposit);
		jpInfo.add (btnSave);
		jpInfo.add (btnCancel);

		//Adding Panel to Window.
		getContentPane().add (jpInfo);

		//In the End Showing the New Account Window.
		setVisible (true);
	
	}

	//Function use By Buttons of Window to Perform Action as User Click Them.
	public void actionPerformed (ActionEvent ae) {

		Object obj = ae.getSource();

		if (obj == btnSave) {
			if (txtAccountNumber.getText().equals("")) {
				JOptionPane.showMessageDialog (this, "Invalid Input for account number, can't be empty",
						" Invalid Input", JOptionPane.PLAIN_MESSAGE);
				txtAccountNumber.requestFocus();
			}
			else if (txtCustomerName.getText().equals("")) {
				JOptionPane.showMessageDialog (this, "Invalid Input for Customer Name, can't be empty",
						" Invalid Input ", JOptionPane.PLAIN_MESSAGE);
				txtCustomerName.requestFocus ();
			}
			else if (txtDeposit.getText().equals("")) {
				JOptionPane.showMessageDialog (this, "Please enter a valid amount",
						"Invalid Input", JOptionPane.PLAIN_MESSAGE);
				txtDeposit.requestFocus ();
			}
			else {
				
					 findBankAccount();		//finding if Account already exists or not
			}
		}
		if (obj == btnCancel) {
			clearTextField ();
			setVisible (false);
			dispose();
		}

	}
	
	void  findBankAccount () {

		boolean found = false;
		Connection connection =null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error in open connection - findBankAccount()");
			System.exit(0);
		}
		System.out.println("Database connected");
				
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Error in createStatement connection - findBankAccount()");
					System.exit(0);
				}
				
			    // Execute a statement
			    ResultSet resultSet = null;
				try {
					resultSet = statement.executeQuery("SELECT COUNT(1) FROM bank WHERE AccNumber = " + txtAccountNumber.getText());
					
					int count = resultSet.getInt(1);
				
				
					if(count>0) {
						found = true;
						JOptionPane.showMessageDialog (this, "Account Number " + txtAccountNumber.getText () + " already exists, please enter a valid account number",
								"Invalid Input", JOptionPane.PLAIN_MESSAGE);
						clearTextField ();
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Error in close connection - findBankAccount() if statement");
							System.exit(0);
						} 
					} else{
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Error in close connection - findBankAccount() else statement");
							System.exit(0);
						} 
						saveBankAccount();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Error in resultSet area findBankAccount() if statement");
					System.exit(0);
				}
				
	}
	
	void saveBankAccount () {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error in open connection - saveBankAccount()");
			System.exit(0);
		}
		System.out.println("Database connected");
		
		String insertSQL = "INSERT INTO bank (AccNumber, CustomerName, Month, Day, Year, Amount)" +
				  " VALUES(?,?, ?,?,?,?)";
		try {
			insertStatement = connection.prepareStatement(insertSQL);
			
			insertStatement.setString(1, txtAccountNumber.getText());
			insertStatement.setString(2, txtCustomerName.getText());
			insertStatement.setObject(3, Month.getSelectedItem());
			insertStatement.setObject(4, Day.getSelectedItem());
			insertStatement.setObject(5, Year.getSelectedItem());
			insertStatement.setString(6, txtDeposit.getText());
			insertStatement.execute();
			
			JOptionPane.showMessageDialog (this, "The Record has been Saved Successfully",
					"BankSystem - Record Saved", JOptionPane.PLAIN_MESSAGE);
			
			clearTextField ();
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error in Insert query at saveBankAccount DB connection");
			System.exit(0);
		}   
		

		finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Error in open connection in saveBankAccount()");
				System.exit(0);
			} 
		} 
	}

	void clearTextField () {

		txtAccountNumber.setText ("");
		txtCustomerName.setText ("");
		txtDeposit.setText ("");
		txtAccountNumber.requestFocus ();

	}
}