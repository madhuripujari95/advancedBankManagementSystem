import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
import java.sql.Statement;
import java.net.*;


public class DepositMoney extends JInternalFrame implements ActionListener {

	private static final long serialVersionUID = 1L; 
	private JPanel jpDep = new JPanel();
	private JLabel lbNo, lbName, lbDate, lbDeposit;
	private JTextField txtAccountNumber, txtCustomerName, txtDeposit;
	private JComboBox Month, Day, Year;
	private JButton btnSave, btnCancel;
	
	Socket socket = null;
	DataOutputStream toServer = null;
	DataInputStream fromServer = null;
	
	private	int currentBalance;
	private	int depositAmount;
	PreparedStatement updateStatement;

	DepositMoney () {

		super ("Deposit Money", false, true, false, true);
		
		setSize (400, 240);

		jpDep.setBounds (0, 0, 500, 115);
		jpDep.setLayout (null);

		lbNo = new JLabel ("Account Number:");
		lbNo.setForeground (Color.black);
		lbNo.setBounds (15, 20, 120, 35);
	    lbName = new JLabel ("Customer Name:");
		lbName.setForeground (Color.black);
	    lbName.setBounds (15, 55, 120, 35);
		lbDate = new JLabel ("Deposit Date:");
		lbDate.setForeground (Color.black);
		lbDate.setBounds (15, 90, 120, 35);
		lbDeposit = new JLabel ("Deposit Amount:");
		lbDeposit.setForeground (Color.black);
		lbDeposit.setBounds (15, 125, 120, 35);

		txtAccountNumber = new JTextField ();
		txtAccountNumber.setHorizontalAlignment (JTextField.RIGHT);
		txtAccountNumber.setBounds (135, 25, 230, 25);
		txtCustomerName = new JTextField ();
		txtCustomerName.setHorizontalAlignment (JTextField.RIGHT);
		txtCustomerName.setBounds (135, 60, 230, 25);
		txtDeposit = new JTextField ();
		txtDeposit.setHorizontalAlignment (JTextField.RIGHT);
		txtDeposit.setBounds (135, 130, 230, 25);

		
		//Creating Date Option.
		String Months[] = {"January", "February", "March", "April", "May", "June",
			"July", "August", "September", "October", "November", "December"};
		Month = new JComboBox (Months);
		Day = new JComboBox ();
		Year = new JComboBox ();
		for (int i = 1; i <= 31; i++) {
			String days = "" + i;
			Day.addItem (days);
		}
		for (int i = 2000; i <= 2021; i++) {
			String years = "" + i;
			Year.addItem (years);
		}

		//Aligning The Date Option Controls.
		Month.setBounds (135, 98, 100, 25);
		Day.setBounds (230, 98, 60, 25);
		Year.setBounds (285, 98, 85, 25);

		//Aligning The Buttons.
		btnSave = new JButton ("Save");
		btnSave.setBounds (35, 165, 120, 25);
		//btnSave.addActionListener (this);
		
		btnSave.addActionListener (new OpenConnectionListener());
		
		btnCancel = new JButton ("Cancel");
		btnCancel.setBounds (200, 165, 120, 25);
		
		btnCancel.addActionListener (this); 
		
		//Restricting The User Input to only Numerics in Numeric TextBoxes.
		txtAccountNumber.addKeyListener (new KeyAdapter() {
			public void keyTyped (KeyEvent ke) {
				char c = ke.getKeyChar ();
				if (!((Character.isDigit (c) || (c == KeyEvent.VK_BACK_SPACE)))) {
					getToolkit().beep ();
					ke.consume ();
      				}
    			}
  		}
		);
		txtDeposit.addKeyListener (new KeyAdapter() {
			public void keyTyped (KeyEvent ke) {
				char c = ke.getKeyChar ();
				if (!((Character.isDigit (c) || (c == KeyEvent.VK_BACK_SPACE)))) {
					getToolkit().beep ();
					ke.consume ();
      				}
    			}
  		}
		);
		//Checking the Account No. Provided By User on Lost Focus of the TextBox.
		txtAccountNumber.addFocusListener (new FocusListener () {
			public void focusGained (FocusEvent e) { }
			public void focusLost (FocusEvent fe) {
				if (txtAccountNumber.getText().equals ("")) { }
				else {
					findBankAccount();		//Finding if Account Number Already Exists in the table
				}
			}
		}
		);

		//Adding the All the Controls to Panel.
		jpDep.add (lbNo);
		jpDep.add (txtAccountNumber);
		jpDep.add (lbName);
		jpDep.add (txtCustomerName);
		jpDep.add (lbDate);
		jpDep.add (Month);
		jpDep.add (Day);
		jpDep.add (Year);
		jpDep.add (lbDeposit);
		jpDep.add (txtDeposit);
		jpDep.add (btnSave);
		jpDep.add (btnCancel);

		//Adding Panel to Window.
		getContentPane().add (jpDep);

		//In the End Showing the New Account Window.
		setVisible (true);

	}
	
	public void actionPerformed(ActionEvent e) {
		
		Object obj = e.getSource();
		
		if (obj == btnCancel) {
			clearTextField ();
			setVisible (false);
			dispose();
		}
	}
	 
	class OpenConnectionListener extends JInternalFrame implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			
			Object obj = e.getSource();
			

			if (obj == btnSave) {
				if (txtAccountNumber.getText().equals("")) {
					JOptionPane.showMessageDialog (this, "Invalid Input for account number",
							" Invalid Input - EmptyField", JOptionPane.PLAIN_MESSAGE);
					txtAccountNumber.requestFocus();
				}
				else if (txtDeposit.getText().equals("")) {
					JOptionPane.showMessageDialog (this, "Please enter a valid deposit amount",
							" Invalid Input - EmptyField", JOptionPane.PLAIN_MESSAGE);
					txtDeposit.requestFocus ();
				}
				else {
					updateBankAccount();	//data sent to SERVER HERE
					JOptionPane.showMessageDialog (this, "Deposit Successful",
							"Transaction complete", JOptionPane.PLAIN_MESSAGE);

					clearTextField ();
				}
			}
		}
	}
		

	//Function use to Find Record by Matching the Contents of Records Array with ID TextBox.
	void findBankAccount() {

		boolean found = false;
		Connection connection =null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Exception in open DB connection - findBankAccount");
			System.exit(0);
		}
		System.out.println("Database connected");
				
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Exception in createStatement DB connection - findBankAccount()");
					System.exit(0);
				}
				
			    // Execute a statement
			    ResultSet resultSet = null;
				try {
					resultSet = statement.executeQuery("SELECT COUNT(1) FROM bank WHERE AccNumber = " + Integer.parseInt(txtAccountNumber.getText()));
					
					int count = resultSet.getInt(1);
				
					if(count==0) {
						JOptionPane.showMessageDialog (this, "Account Number " + txtAccountNumber.getText () + " doesn't exist, please enter a valid account number",
								"Invalid Input", JOptionPane.PLAIN_MESSAGE);
						
						clearTextField ();
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Exception in close DB connection - findBankAccount");
							System.exit(0);
						} 
					} else{
						found = true;
						displayBankAccount();
						
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Exception in close DB connection - findBankAccount");
							System.exit(0);
						} 
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.exit(0);
				}
				
	}	


	public void displayBankAccount () {
		
		Connection connection =null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Exception in open DB connection - displayBankAccount");
			System.exit(0);
		}
		System.out.println("Database connected");
				
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Exception in createStatement DB connection  - displayBankAccount ");
					System.exit(0);
				}
				
			    // Execute a statement
			    ResultSet resultSet = null;
				try {
					resultSet = statement.executeQuery("SELECT AccNumber, CustomerName, Amount FROM bank WHERE AccNumber = " 
				+ Integer.parseInt(txtAccountNumber.getText()));
					
					txtAccountNumber.setText (resultSet.getString(1));
					txtCustomerName.setText (resultSet.getString(2));
					currentBalance = Integer.parseInt(resultSet.getString(3));	
					
					
				} catch (SQLException e) {
					e.printStackTrace();
					System.exit(0);
				}

			    // Close the connection
			   finally {
			      try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Exception in close DB connection - findBankAccount");
					System.exit(0);
				}
			   }
	 }

	//Function use to Clear all TextFields of Window.
	void clearTextField () {

		txtAccountNumber.setText ("");
		txtCustomerName.setText ("");
		txtDeposit.setText ("");
		txtAccountNumber.requestFocus ();

	}

	//Function to update send the details to server for table updation
	public void updateBankAccount () {
		
				depositAmount = Integer.parseInt(txtDeposit.getText());
			  	try {
					socket = new Socket("localhost", 8000);
				} catch (IOException e1) {
					e1.printStackTrace();
					System.out.println("Client request failed");
				}
			  	
				
				try{
					
					fromServer = new DataInputStream(socket.getInputStream());
					toServer = new DataOutputStream(socket.getOutputStream());
					
					int flagFromDeposit = 1;
					int accountNumber = Integer.parseInt(txtAccountNumber.getText());
					
					toServer.writeInt(flagFromDeposit);
					toServer.writeInt(accountNumber);
					toServer.writeInt(depositAmount);
					toServer.writeInt(currentBalance);
	
					toServer.flush();

				    
					}catch (IOException ex) {
						System.err.println(ex);
					
			      } finally {
				    try { 
				    	socket.close(); 
				    	} catch (Exception e1) {
				    		}
				}
			
	
	}


}	