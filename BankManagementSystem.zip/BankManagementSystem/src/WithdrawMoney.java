import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import java.io.*;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
import java.sql.Statement;

public class WithdrawMoney extends JInternalFrame implements ActionListener {
	
	private static final long serialVersionUID = 1L; 
	private JPanel jpWith = new JPanel();
	private JLabel lbNo, lbName, lbDate, lbWithdraw;
	private JTextField txtAccountNumber, txtCustomerName, txtWithdraw;
	private JComboBox Month, Day, Year;
	private JButton btnSave, btnCancel;

	
	Socket socket = null;
	DataOutputStream toServer = null;
	DataInputStream fromServer = null;

	private	int currentBalance;
	private	int WithdrawAmount;

	PreparedStatement updateStatement, insertStatement;
	
	WithdrawMoney () {

		super ("Withdraw Money", false, true, false, true);
		
		setSize (400, 240);

		jpWith.setLayout (null);

		lbNo = new JLabel ("Account Number:");
		lbNo.setForeground (Color.black);
		lbNo.setBounds (15, 20, 120, 35);
	    lbName = new JLabel ("Customer Name:");
		lbName.setForeground (Color.black);
	    lbName.setBounds (15, 55, 120, 35);
		lbDate = new JLabel ("Deposit Date:");
		lbDate.setForeground (Color.black);
		lbDate.setBounds (15, 90, 120, 35);
		lbWithdraw = new JLabel ("Withdraw Amount:");
		lbWithdraw.setForeground (Color.black);
		lbWithdraw.setBounds (15, 125, 120, 35);


		txtAccountNumber = new JTextField ();
		txtAccountNumber.setHorizontalAlignment (JTextField.RIGHT);

		
		txtAccountNumber.addFocusListener (new FocusListener () {
			public void focusGained (FocusEvent e) { }
			
			public void focusLost (FocusEvent fe) {
				if (txtAccountNumber.getText().equals ("")) { }
				else {
					findBankAccount ();		//Finding if Account Number exists
				}
			}
		}
		);
		txtAccountNumber.setBounds (135, 25, 230, 25);
		txtAccountNumber.setHorizontalAlignment (JTextField.RIGHT);

		txtCustomerName = new JTextField ();
		txtCustomerName.setEnabled (false);
		txtAccountNumber.setHorizontalAlignment (JTextField.RIGHT);
		txtCustomerName.setBounds(135, 60, 230, 25);
		
		txtWithdraw = new JTextField ();
		txtWithdraw.setHorizontalAlignment (JTextField.RIGHT);
		txtWithdraw.setBounds  (135, 130, 230, 25);


		//Restricting The User Input to only Numerics in Numeric TextBoxes.
		txtAccountNumber.addKeyListener (new KeyAdapter() {
			public void keyTyped (KeyEvent ke) {
				char c = ke.getKeyChar ();
				if (!((Character.isDigit (c) || (c == KeyEvent.VK_BACK_SPACE)))) {
					getToolkit().beep ();
					ke.consume ();
      				}
    			}
  		}
		);
		txtWithdraw.addKeyListener (new KeyAdapter() {
			public void keyTyped (KeyEvent ke) {
				char c = ke.getKeyChar ();
				if (!((Character.isDigit (c) || (c == KeyEvent.VK_BACK_SPACE)))) {
					getToolkit().beep ();
					ke.consume ();
      				}
    			}
  		}
		);

		//Creating Date Option.
		String Months[] = {"January", "February", "March", "April", "May", "June",
			"July", "August", "September", "October", "November", "December"};
		Month = new JComboBox (Months);
		Day = new JComboBox ();
		Year = new JComboBox ();
		for (int i = 1; i <= 31; i++) {
			String days = "" + i;
			Day.addItem (days);
		}
		for (int i = 2000; i <= 2020; i++) {
			String years = "" + i;
			Year.addItem (years);
		}

		//Aligning The Date Option Controls.
		Month.setBounds (135, 98, 100, 25);
		Day.setBounds (230, 98, 60, 25);
		Year.setBounds (285, 98, 85, 25);

		//Aligning The Buttons.
		btnSave = new JButton ("Save");
		btnSave.setBounds (35, 165, 120, 25);
		btnSave.addActionListener (new OpenConnectionListener());
		btnCancel = new JButton ("Cancel");
		btnCancel.setBounds (200, 165, 120, 25);
		btnCancel.addActionListener (this);

		//Adding the All the Controls to Panel.
		jpWith.add (lbNo);
		jpWith.add (txtAccountNumber);
		jpWith.add (lbName);
		jpWith.add (txtCustomerName);
		jpWith.add (lbDate);
		jpWith.add (Month);
		jpWith.add (Day);
		jpWith.add (Year);
		jpWith.add (lbWithdraw);
		jpWith.add (txtWithdraw);
		jpWith.add (btnSave);
		jpWith.add (btnCancel);

		//Adding Panel to Window.
		getContentPane().add (jpWith);

		//In the End Showing the New Account Window.
		setVisible (true);

	}
	public void actionPerformed(ActionEvent e) {
		
		Object obj = e.getSource();
		
		if (obj == btnCancel) {
			clearTextField ();
			setVisible (false);
			dispose();
		}
	}

	//Function use By Buttons of Window to Perform Action as User Click Them.
	class OpenConnectionListener extends JInternalFrame implements ActionListener {		
		@Override
		public void actionPerformed (ActionEvent ae) {
	
			Object obj = ae.getSource();
	
			if (obj == btnSave) {
				if (txtAccountNumber.getText().equals("")) {
					JOptionPane.showMessageDialog (this, "Invalid Input for account number",
							" Invalid Input", JOptionPane.PLAIN_MESSAGE);
					txtAccountNumber.requestFocus();
				}
				else if (txtWithdraw.getText().equals("")) {
					JOptionPane.showMessageDialog (this, "Please enter a valid withdrawal amount",
							"Invalid Input", JOptionPane.PLAIN_MESSAGE);
					txtWithdraw.requestFocus ();
				}
				else {
					WithdrawAmount = Integer.parseInt (txtWithdraw.getText ());
					if (currentBalance == 0) {
						JOptionPane.showMessageDialog (this, txtCustomerName.getText () + " Zero Balance",
								"Invalid Input - EmptyAccount", JOptionPane.PLAIN_MESSAGE);
						clearTextField ();
					}
					else if (WithdrawAmount > currentBalance) {
						JOptionPane.showMessageDialog (this, "Withdraw Amount greater than Actual Balance",
								"Invalid Input - Large Amount", JOptionPane.PLAIN_MESSAGE);
						txtWithdraw.setText ("");
						txtWithdraw.requestFocus ();
					}
					else {
						updateBankAccount ();
						JOptionPane.showMessageDialog (this, "Withdrawal Successful",
						"Transaction Complete", JOptionPane.PLAIN_MESSAGE);
						clearTextField ();
						
					}
				}
			}
		}
	}
	
	void findBankAccount() {

		boolean found = false;
		Connection connection =null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Withdraw - Exception in open DB connection - findBankAccount");
			System.exit(0);
		}
		System.out.println("Database connected");
				
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Withdraw - Exception in createStatement connection - findBankAccount()");
					System.exit(0);
				}
				
			    // Execute a statement
			    ResultSet resultSet = null;
				try {
					resultSet = statement.executeQuery("SELECT COUNT(1) FROM bank WHERE AccNumber = " + Integer.parseInt(txtAccountNumber.getText()));	
					int count = resultSet.getInt(1);
				
					if(count==0) {
						JOptionPane.showMessageDialog (this, "Account Number " + txtAccountNumber.getText () + " doesn't exist, please enter a valid account number",
								"Incorrect Account Number", JOptionPane.PLAIN_MESSAGE);
						
						clearTextField ();
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Withdraw - Exception in close DB connection - findBankAccount() if statement");
							System.exit(0);
						} 
					} else{
						found = true;
						displayBankAccount();
	
						try {
							connection.close();
						} catch (SQLException e) {
							e.printStackTrace();
							System.out.println("Withdraw - Exception in close DB connection - findBankAccount() else statement");
							System.exit(0);
						} 
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.exit(0);
				}
				
	}	


	public void displayBankAccount () {
		Connection connection =null;
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:bank.db");
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("Withdraw - Exception in open connection in displayBankAccount");
				System.exit(0);
			}
			System.out.println("Database connected");
						
		Statement statement = null;
		try {
			statement = connection.createStatement();
			} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Exception in createStatement DB connection in displayBankAccount");
					System.exit(0);
				}
				
	    // Execute a statement
	    ResultSet resultSet = null;
		try {
			resultSet = statement.executeQuery("SELECT AccNumber, CustomerName, Amount FROM bank WHERE AccNumber = " 
		+ Integer.parseInt(txtAccountNumber.getText()));
			
			txtAccountNumber.setText (resultSet.getString(1));
			txtCustomerName.setText (resultSet.getString(2));
			
			currentBalance = Integer.parseInt(resultSet.getString(3));	
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Withdraw - Exception in resultSet area in displayBankAccount");
			System.exit(0);
		}

	    // Close the connection
	   finally {
	      try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Withdraw - Exception in close connection in displayBankAccount");
			System.exit(0);
		}
	   }
			 }


	//Function use to Clear all TextFields of Window.
	void clearTextField () {
		txtAccountNumber.setText ("");
		txtCustomerName.setText ("");
		txtWithdraw.setText ("");
		txtAccountNumber.requestFocus ();

	}

	public void updateBankAccount () {
		try {
			socket = new Socket("localhost", 8000);
			System.out.println("Client request sent");
		} catch (IOException e1) {
			e1.printStackTrace();
			System.out.println("Client request failed");
		}
	  	
		
		try{
			fromServer = new DataInputStream(socket.getInputStream());
			
			toServer = new DataOutputStream(socket.getOutputStream());
			
			int flagFromWithdraw = 2;
			int accountNumber = Integer.parseInt(txtAccountNumber.getText());

			
			toServer.writeInt(flagFromWithdraw);
			toServer.writeInt(accountNumber);
			toServer.writeInt(WithdrawAmount);
			toServer.writeInt(currentBalance);

			
			toServer.flush();
		    
		    
			}catch (IOException ex) {
				System.err.println(ex);
			
	      } finally {
		    try { 
		    	socket.close(); 
		    	} catch (Exception e1) {
		    		}
		}
		
	
	}


}	